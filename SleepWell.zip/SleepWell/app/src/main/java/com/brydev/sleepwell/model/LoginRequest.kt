package com.brydev.sleepwell.model

data class LoginRequest(
    val email: String,
    val password: String
)
